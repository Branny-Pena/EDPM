/* 
 * File:   main.c
 * Author: Branny
 *
 * Created on September 17, 2022, 9:44 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include "ArbolesBinarios.h"

int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

