/* 
 * File:   main.c
 * Author: Branny
 *
 * Created on September 28, 2022, 9:28 AM
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

