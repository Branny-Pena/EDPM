/* 
 * File:   main.c
 * Author: Branny
 *
 * Created on September 27, 2022, 8:21 AM
 */

#include <stdio.h>
#include <stdlib.h>


int main(int argc, char** argv) {
    
    return (EXIT_SUCCESS);
}

